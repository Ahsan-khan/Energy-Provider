﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EnergyProviderWebApp
{
    public partial class EnergyProvider : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Remove or comment out the following line:
                // BindData("SELECT * FROM Region", gvRegions);
            }
        }

        protected void btnShowAllTables_Click(object sender, EventArgs e)
        {
            string[] tableNames = { "Region", "Products", "Customer", "Sales", "Import", "Maintenance", "Cost", "Billing", "FinancialRisk" };

            phTables.Controls.Clear();

            foreach (string tableName in tableNames)
            {
                Label lblTableName = new Label();
                lblTableName.Text = tableName;
                phTables.Controls.Add(lblTableName);

                GridView gvTable = new GridView();
                phTables.Controls.Add(gvTable);

                try
                {
                    using (SqlConnection connection = new SqlConnection(GetConnectionString()))
                    {
                        connection.Open();
                        using (SqlCommand command = new SqlCommand($"SELECT * FROM {tableName}", connection))
                        {
                            SqlDataAdapter adapter = new SqlDataAdapter(command);
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            gvTable.DataSource = dt;
                            gvTable.DataBind();
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Handle the exception (e.g., show an error message)
                }
            }
        }


        private void LoadRegions()
        {
            using (SqlConnection connection = new SqlConnection(GetConnectionString()))
            {
                using (SqlCommand command = new SqlCommand("SELECT * FROM Region", connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    gvRegions.DataSource = dataTable;
                    gvRegions.DataBind();
                }
            }
        }

        private void LoadCustomers()
        {
            using (SqlConnection connection = new SqlConnection(GetConnectionString()))
            {
                using (SqlCommand command = new SqlCommand("SELECT * FROM Customer", connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    gvCustomers.DataSource = dataTable;
                    gvCustomers.DataBind();
                }
            }
        }

        private void LoadSales()
        {
            using (SqlConnection connection = new SqlConnection(GetConnectionString()))
            {
                using (SqlCommand command = new SqlCommand("SELECT * FROM Sales", connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    gvSales.DataSource = dataTable;
                    gvSales.DataBind();
                }
            }
        }

        private void BindCustomers()
        {
            using (SqlConnection connection = new SqlConnection(GetConnectionString()))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("SELECT * FROM Customer", connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    gvCustomers.DataSource = dataTable;
                    gvCustomers.DataBind();
                }
            }
        }

        protected void btnExecute_Click(object sender, EventArgs e)
        {
            string query = txtQuery.Text.Trim();
            if (!string.IsNullOrEmpty(query))
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(GetConnectionString()))
                    {
                        connection.Open();
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            SqlDataAdapter adapter = new SqlDataAdapter(command);
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            gvResults.DataSource = dt;
                            gvResults.DataBind();
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Handle the exception (e.g., show an error message)
                }
            }
        }

        private static string GetConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["MyDatabaseConnectionString"].ConnectionString;
        }

    }
}

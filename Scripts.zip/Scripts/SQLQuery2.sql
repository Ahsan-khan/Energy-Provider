CREATE TABLE Region ( 
    RegionId int not null, 
    RegionName character, 
    PRIMARY KEY(RegionId) 
); 

CREATE TABLE Products(
    ProductID int not null,
    ProductName VARCHAR(100),
    PRIMARY KEY (ProductID)
);

CREATE TABLE Customer( 
    CustomerID int not null, 
    CustomerName CHARACTER not null, 
    CustAddress VARCHAR(100), 
    ContactInfo varchar(50) not null, 
    PRIMARY KEY (CustomerId) 
);

CREATE TABLE Sales (  
    SalesId int NOT null,  
    ProductID int NOT NULL,  
    ProductName CHARACTER(25),  
    Dates DATE,       
    Price int NOT NULL,  
    Quantity int NOT NULL,  
    RegionId int NOT NULL,  
    CustomerId int NOT NULL,  
    PRIMARY KEY (SalesId), 
    FOREIGN KEY (RegionId) REFERENCES Region(RegionId),           	                
	FOREIGN KEY (CustomerId) REFERENCES Customer(CustomerID) 
);

CREATE TABLE Import (
    SalesId INT NOT NULL, 	 
    ProductID INT NOT NULL, 
    Dates DATE NOT NULL, 
    Price INT NOT NULL, 
    Quantity INT, 
    RegionID INT NOT NULL,  
    CustomerId INT NOT NULL, 
    FOREIGN KEY (RegionId) REFERENCES Region(RegionId), 
    FOREIGN KEY (CustomerId) REFERENCES Customer(CustomerID),
    FOREIGN KEY (ProductId) REFERENCES Products(ProductID)
);

CREATE TABLE Maintenance ( 
    RegionId INT NOT NULL, 
    ProductId INT NOT NULL, 
    Dates DATE, 
    Type VARCHAR(50), 
    Cost INT, 
    FOREIGN KEY (RegionId) REFERENCES Region(RegionId), 
    FOREIGN KEY (ProductId) REFERENCES Products(ProductID) 
);

CREATE TABLE Cost ( 
    ProductID int not null, 
    Type varchar(40), 
    Description character(150), 
    Amount int, 
    RegionId int not null, 
    FOREIGN KEY (RegionId) REFERENCES Region(RegionId), 
    FOREIGN KEY (ProductId) REFERENCES Products(ProductID) 
);

CREATE TABLE Billing (
    SalesId int not null, 
    CustomerId int not null, 
    Dates DATE, 
    Amount int , 
    PaymentStatus CHARACTER(15) not null, 
    FOREIGN KEY (SalesId) REFERENCES Sales(SalesID), 
    FOREIGN KEY (CustomerId) REFERENCES Customer(CustomerID) 
);

CREATE TABLE FinancialRisk ( 
    RegionId int not null, 
    CustomerID int not null, 
    AmountAtRisk int, 
    OverdueSince date, 
    FOREIGN KEY (RegionId) REFERENCES Region(RegionId),
    FOREIGN KEY (CustomerId) REFERENCES Customer(CustomerID)
);

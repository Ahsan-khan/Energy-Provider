-- Inserting dummy values into Region
INSERT INTO Region (RegionId, RegionName) VALUES
(1, 'North'),
(2, 'South'),
(3, 'East'),
(4, 'West'),
(5, 'Central');

-- Inserting dummy values into Products
INSERT INTO Products (ProductID, ProductName) VALUES
(1, 'Product A'),
(2, 'Product B'),
(3, 'Product C'),
(4, 'Product D'),
(5, 'Product E');

-- Inserting dummy values into Customer
INSERT INTO Customer (CustomerID, CustomerName, CustAddress, ContactInfo) VALUES
(1, 'John Doe', '123 Main St', '555-1234'),
(2, 'Jane Smith', '456 Market St', '555-5678'),
(3, 'Jim Brown', '789 Elm St', '555-9012'),
(4, 'Mary Johnson', '246 Oak St', '555-3456'),
(5, 'Robert Davis', '135 Pine St', '555-7890');

-- Inserting dummy values into Sales
INSERT INTO Sales (SalesId, ProductID, ProductName, Dates, Price, Quantity, RegionId, CustomerId) VALUES
(1, 1, 'Product A', '2023-01-01', 50, 10, 1, 1),
(2, 2, 'Product B', '2023-01-02', 30, 15, 2, 2),
(3, 3, 'Product C', '2023-01-03', 40, 20, 3, 3),
(4, 4, 'Product D', '2023-01-04', 60, 25, 4, 4),
(5, 5, 'Product E', '2023-01-05', 70, 30, 5, 5);

-- Inserting dummy values into Import
INSERT INTO Import (SalesId, ProductID, Dates, Price, Quantity, RegionID, CustomerId) VALUES
(1, 1, '2023-01-06', 50, 10, 1, 1),
(2, 2, '2023-01-07', 30, 15, 2, 2),
(3, 3, '2023-01-08', 40, 20, 3, 3),
(4, 4, '2023-01-09', 60, 25, 4, 4),
(5, 5, '2023-01-10', 70, 30, 5, 5);

-- Inserting dummy values into Maintenance
INSERT INTO Maintenance (RegionId, ProductId, Dates, Type, Cost) VALUES
(1, 1, '2023-01-11', 'Repair', 100),
(2, 2, '2023-01-12', 'Maintenance', 200),
(3, 3, '2023-01-13', 'Upgrade', 300),
(4, 4, '2023-01-14', 'Repair', 400),
(5, 5, '2023-01-15', 'Maintenance', 500);

-- Inserting dummy values into Cost
INSERT INTO Cost (ProductID, Type, Description, Amount, RegionId) VALUES
(1, 'Shipping', 'Shipping cost for Product A', 10, 1),
(2, 'Shipping', 'Shipping cost for Product B', 20, 2),
(3, 'Shipping', 'Shipping cost for Product C', 30, 3),
(4, 'Shipping', 'Shipping cost for Product D', 40, 4),
(5, 'Shipping', 'Shipping cost for Product E', 50, 5);

-- Inserting dummy values into Billing
INSERT INTO Billing (SalesId, CustomerId, Dates, Amount, PaymentStatus) VALUES
(1, 1, '2023-01-16', 500, 'Paid'),
(2, 2, '2023-01-17', 450, 'Paid'),
(3, 3, '2023-01-18', 800, 'Unpaid'),
(4, 4, '2023-01-19', 1500, 'Paid'),
(5, 5, '2023-01-20', 2100, 'Unpaid');

-- Inserting dummy values into FinancialRisk
INSERT INTO FinancialRisk (RegionId, CustomerID, AmountAtRisk, OverdueSince) VALUES
(1, 1, 1000, '2023-01-16'),
(2, 2, 1500, '2023-01-17'),
(3, 3, 2000, '2023-01-18'),
(4, 4, 2500, '2023-01-19'),
(5, 5, 3000, '2023-01-20');


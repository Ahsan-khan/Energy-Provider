--Calculate the total maintenance cost per product for each region:
SELECT p.ProductName, r.RegionName, SUM(m.Cost) AS TotalMaintenanceCost
FROM Maintenance m
JOIN Products p ON m.ProductId = p.ProductID
JOIN Region r ON m.RegionId = r.RegionId
GROUP BY p.ProductName, r.RegionName
ORDER BY TotalMaintenanceCost DESC;

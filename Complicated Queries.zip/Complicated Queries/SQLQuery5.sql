--Get the total overdue amounts and count of overdue customers per region:
SELECT r.RegionName, SUM(fr.AmountAtRisk) AS TotalOverdueAmount, COUNT(*) AS OverdueCustomers
FROM FinancialRisk fr
JOIN Region r ON fr.RegionId = r.RegionId
WHERE fr.OverdueSince IS NOT NULL
GROUP BY r.RegionName
ORDER BY TotalOverdueAmount DESC;

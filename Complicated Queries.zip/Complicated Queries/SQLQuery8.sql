--Retrieve all sales data with customer and product information:
SELECT s.SalesId, s.Dates, s.Price, s.Quantity, c.CustomerName, p.ProductName
FROM Sales s
JOIN Customer c ON s.CustomerId = c.CustomerID
JOIN Products p ON s.ProductID = p.ProductID;

--Find the top 5 customers by total sales amount:
SELECT TOP 5 c.CustomerName, SUM(s.Price * s.Quantity) AS TotalSales
FROM Sales s
JOIN Customer c ON s.CustomerId = c.CustomerId
GROUP BY c.CustomerName
ORDER BY TotalSales DESC;
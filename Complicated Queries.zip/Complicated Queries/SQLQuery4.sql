--Find the products with the highest total cost (Cost + Maintenance) per region:
WITH TotalCost AS (
    SELECT p.ProductName, r.RegionName, SUM(c.Amount + COALESCE(m.Cost, 0)) AS TotalCost
    FROM Cost c
    JOIN Products p ON c.ProductId = p.ProductID
    JOIN Region r ON c.RegionId = r.RegionId
    LEFT JOIN Maintenance m ON c.ProductId = m.ProductId AND c.RegionId = m.RegionId
    GROUP BY p.ProductName, r.RegionName
)
, MaxCost AS (
    SELECT tc.RegionName, MAX(tc.TotalCost) AS HighestTotalCost
    FROM TotalCost tc
    GROUP BY tc.RegionName
)
SELECT tc.RegionName, tc.ProductName, tc.TotalCost AS HighestTotalCost
FROM TotalCost tc
JOIN MaxCost mc ON tc.RegionName = mc.RegionName AND tc.TotalCost = mc.HighestTotalCost;


--Retrieve all customers with an overdue financial risk:
SELECT c.CustomerName, fr.AmountAtRisk, fr.OverdueSince
FROM FinancialRisk fr
JOIN Customer c ON fr.CustomerID = c.CustomerID
WHERE fr.OverdueSince IS NOT NULL;

--Get the total sales revenue for each region:
SELECT r.RegionName, SUM(s.Price * s.Quantity) AS TotalRevenue
FROM Sales s
JOIN Region r ON s.RegionId = r.RegionId
GROUP BY r.RegionName
ORDER BY TotalRevenue DESC;
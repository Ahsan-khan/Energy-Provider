--Retrieve the total sales amount per region:
SELECT r.RegionName, SUM(s.Price * s.Quantity) as TotalSalesAmount
FROM Sales s
JOIN Region r ON s.RegionId = r.RegionId
GROUP BY r.RegionName;
